# 小红书内容库

这是独立的小红书专用库，不会合并到原有知识库。

1. 在 Obsidian 中选择“打开文件夹作为仓库”，选择此文件夹。
2. 在 ExternalBrain → 商务总览 → 选择 Obsidian 库，选择同一文件夹。
3. 先在 ExternalBrain 新建项目、账号和选题，再打开内容工作台，点击“在 Obsidian 编辑”或“刷新预览”建立关联笔记。
4. 在笔记的“正文”“话题”“配图”“排版备注”中编辑内容。返回 ExternalBrain 后点击“刷新预览”。

`内容/` 保存稿件，`附件/` 保存图片，`模板/` 提供写作结构参考。

图片可在 Obsidian 中嵌入，也可在 ExternalBrain 中导入。图片嵌入顺序就是预览顺序，第一张作为封面。支持本地 PNG、JPEG、WebP、GIF、AVIF；同名图片无法唯一定位时，请使用包含文件夹的链接。

不要删除或改动稿件属性里的 `externalbrain_id` 和 `project_id`。笔记可以改名和移动，软件会通过固定 ID 重新定位；复制笔记时不要保留重复的内容 ID。

请通过 ExternalBrain 的“导出备份”定期保存包含数据库记录、Markdown 和图片的完整 JSON 备份。Obsidian 本身不会替你备份数据库。
